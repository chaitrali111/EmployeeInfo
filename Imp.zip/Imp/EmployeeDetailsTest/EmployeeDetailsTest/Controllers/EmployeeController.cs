﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeDetailsTest.Repository;

namespace EmployeeDetailsTest.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/
        //DelivaryRepositary dal = new DelivaryRepositary();
        private IEmployeeRepository _employeeRepository;

        public EmployeeController()
        {
            _employeeRepository = new EmployeeRepositary();
        }
        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }  
  
        public ActionResult Index()
        {
           
            //EmployeeData emp = new EmployeeData();
           // ViewBag.LocatnList = new SelectList(_employeeRepository.GetLocationList(), "LocationID", "LocationName"); 
            if (TempData["EmpData"] != null)
            {
                var emps = TempData["EmpData"];
                return View(emps);
            }
            else
            {
                var emp = _employeeRepository.GetAll(0);
                return View(emp);
            }
           
        }
        public ActionResult AddEmployee()
        {
            if (TempData["Failed"] != null)
            {
                ViewBag.Failed = "Add Employee Failed";
            }
            return View();
        }

       
        public JsonResult LocationList()
        {
            var model = _employeeRepository.GetLocationList().ToList();
            
            return Json(model, JsonRequestBehavior.AllowGet);


        }

       
        public ActionResult GetAllEmployeeDataByFilter(string Age,string Salary,string LocationName)
        {
           
            var emp = _employeeRepository.GetEmployeeAllbyfiltring(Age,Salary,LocationName);
             TempData["EmpData"] = emp ;

             //return Json(emp, JsonRequestBehavior.AllowGet); 
            return RedirectToAction("Index");
           
        }

        [HttpPost]
        public ActionResult AddEmployee(EmployeeData model)
        {
            if (ModelState.IsValid)
            {
                //model.LocationID = 1;
                int result = _employeeRepository.Insert(model);
                if (result > 0)
                {
                    return RedirectToAction("Index", "Employee");
                }
                else
                {
                    TempData["Failed"] = "Failed";
                    return RedirectToAction("AddEmployee", "Employee");
                }
            }
            return View();
        }

        public ActionResult EditEmployee(int EmployeeId)
        {
            if (TempData["Failed"] != null)
            {
                ViewBag.Failed = "Edit Employee Failed";
            }

           
            var model = _employeeRepository.GetById(EmployeeId);
            return View(model);
        }

        [HttpPost]
        public ActionResult EditEmployee(EmployeeData model)
        {
            if (ModelState.IsValid)
            {
                int result = _employeeRepository.Update(model);
                if (result > 0)
                {
                    return RedirectToAction("Index", "Employee");
                }
                else
                {

                    return RedirectToAction("Index", "Employee");
                }
            }
            return View();
        }


        public ActionResult DeleteEmployee(int EmployeeId)
        {
            int model = _employeeRepository.Delete(EmployeeId);
           
            return RedirectToAction("Index", "Employee");
        }

        //[HttpPost]
        //public ActionResult DeleteEmployee(EmployeeData model)
        //{
        //    if (TempData["Failed"] != null)
        //    {
        //        ViewBag.Failed = "Delete Employee Failed";
        //    }
        //    _employeeRepository.Delete(model.ID);
        //    return RedirectToAction("Index", "Employee");
        //}  
  
    }
}

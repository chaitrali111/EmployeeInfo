﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeDetailsTest.Repository
{
    public interface IEmployeeRepository
    {


        IEnumerable<EmployeeData> GetAll(int ID);
        EmployeeData GetById(int EmployeeID);
        int Insert(EmployeeData employee);
        int Update(EmployeeData employee);
        int Delete(int EmployeeID);
        List<Location> GetLocationList();
        List<EmployeeData> GetEmployeeAllbyfiltring(string Age, string Salary, string LocationName);
    }
}

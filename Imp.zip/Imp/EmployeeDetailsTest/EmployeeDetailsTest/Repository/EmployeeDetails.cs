﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EmployeeDetailsTest.Repository
{
    public class EmployeeDetails
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Connstring"].ToString());
        public int InsertUpdateEmployeeDetails(EmployeeData Emp)
        {
           int val=0;
           SqlCommand cmd = new SqlCommand("InsertUpdateEmployeeDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", Emp.ID);
            cmd.Parameters.AddWithValue("@Name", Emp.Name);
            cmd.Parameters.AddWithValue("@Age", Emp.Age);
            cmd.Parameters.AddWithValue("@MaritalStatus", Emp.MaritalStatus);
            cmd.Parameters.AddWithValue("@Salary", Emp.Salary);
            cmd.Parameters.AddWithValue("@LocationID", Emp.LocationName);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            List<Location> LocList = new List<Location>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {

                val = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            }
            return val;  
        }

        public List<Location> GetLocationList()
        {
            EmployeeData emp = new EmployeeData();
            SqlCommand cmd = new SqlCommand("GetLocationList", con);
            cmd.CommandType = CommandType.StoredProcedure;
                       con.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            List<Location> LocList = new List<Location>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Location Loc = new Location();
                Loc.LocationId = Convert.ToInt32(ds.Tables[0].Rows[i]["LocationId"].ToString());
                Loc.LocationName = ds.Tables[0].Rows[i]["LocationName"].ToString();

                LocList.Add(Loc);
              
            }
           
            return LocList;
        }

        public EmployeeData GetEmployeeByID(int ID)
        {
           
            SqlCommand cmd = new SqlCommand("GetAllEmployeeDetails", con);
            cmd.Parameters.AddWithValue("@ID", ID);  
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            EmployeeData Emp = new EmployeeData();
            List<EmployeeData> EmpList = new List<EmployeeData>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
              
                Emp.Srno = Convert.ToInt32(ds.Tables[0].Rows[i]["SrNo"]);
                Emp.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["FieldId"]);
                Emp.Name =Convert.ToString(ds.Tables[0].Rows[i]["Name"]);
                Emp.Age = Convert.ToInt32(ds.Tables[0].Rows[i]["Age"]);
                Emp.MaritalStatus = Convert.ToString(ds.Tables[0].Rows[i]["MaritalStatus"]);
                Emp.Salary = Convert.ToInt32(ds.Tables[0].Rows[i]["Salary"]);
                Emp.LocationName = Convert.ToString(ds.Tables[0].Rows[i]["LocationName"]);
                
            }

            return Emp;
        }

        public List<EmployeeData> GetEmployeeAll(int ID)
        {

            SqlCommand cmd = new SqlCommand("GetAllEmployeeDetails", con);
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            
            List<EmployeeData> EmpList = new List<EmployeeData>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                EmployeeData Emp = new EmployeeData();
                Emp.Srno = Convert.ToInt32(ds.Tables[0].Rows[i]["SrNo"]);
                Emp.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["FieldId"]);
                Emp.Name = Convert.ToString(ds.Tables[0].Rows[i]["Name"]);
                Emp.Age = Convert.ToInt32(ds.Tables[0].Rows[i]["Age"]);
                Emp.MaritalStatus = Convert.ToString(ds.Tables[0].Rows[i]["MaritalStatus"]);
                Emp.Salary = Convert.ToInt32(ds.Tables[0].Rows[i]["Salary"]);
                Emp.LocationName = Convert.ToString(ds.Tables[0].Rows[i]["LocationName"]);
                EmpList.Add(Emp);
            }

            return EmpList;
        }

        public List<EmployeeData> GetEmployeeAllbyfiltring(string Age, string Salary, string LocationName)
        {

            SqlCommand cmd = new SqlCommand("GetAllEmployeeDetailsbyFilter", con);
            cmd.Parameters.AddWithValue("@Age", Age==null?"":Age);
            cmd.Parameters.AddWithValue("@Salary", Salary==null?"":Salary);
            cmd.Parameters.AddWithValue("@LocationName", LocationName==null?"":LocationName);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);

            List<EmployeeData> EmpList = new List<EmployeeData>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                EmployeeData Emp = new EmployeeData();
                Emp.Srno = Convert.ToInt32(ds.Tables[0].Rows[i]["SrNo"]);
                Emp.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["FieldId"]);
                Emp.Name = Convert.ToString(ds.Tables[0].Rows[i]["Name"]);
                Emp.Age = Convert.ToInt32(ds.Tables[0].Rows[i]["Age"]);
                Emp.MaritalStatus = Convert.ToString(ds.Tables[0].Rows[i]["MaritalStatus"]);
                Emp.Salary = Convert.ToInt32(ds.Tables[0].Rows[i]["Salary"]);
                Emp.LocationName = Convert.ToString(ds.Tables[0].Rows[i]["LocationName"]);
                EmpList.Add(Emp);
            }

            return EmpList;
        }
        public int DeleteEmployeeDetails(int ID)
        {
           
            SqlCommand cmd = new SqlCommand("DeleteEmployeeDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);           
            con.Open();
            int result = Convert.ToInt32(cmd.ExecuteScalar());
            return result;
        }
    }
}
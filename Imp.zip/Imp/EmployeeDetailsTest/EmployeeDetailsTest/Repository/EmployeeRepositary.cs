﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeDetailsTest.Repository
{
    public class EmployeeRepositary:IEmployeeRepository
    {

        //public EmployeeRepositary()
        //    {
        //        EmployeeDetails Emp = new EmployeeDetails();
        //    }

           
            public IEnumerable<EmployeeData> GetAll(int id)
            {
                int ID = 0;
                EmployeeDetails Emp = new EmployeeDetails();
                List<EmployeeData> EmpList = new List<EmployeeData>();
              EmpList=Emp.GetEmployeeAll(ID);
              return EmpList;
            }
            public List<EmployeeData> GetEmployeeAllbyfiltring(string Age, string Salary, string LocationName)
            {
                int ID = 0;
                EmployeeDetails Emp = new EmployeeDetails();
                List<EmployeeData> EmpList = new List<EmployeeData>();
              EmpList=Emp.GetEmployeeAllbyfiltring(Age, Salary, LocationName);
              return EmpList;
            }
       

            public List<Location> GetLocationList()
            {
                int ID = 0;
                EmployeeDetails Emp = new EmployeeDetails();
                List<Location> LocList = new List<Location>();
                LocList = Emp.GetLocationList();
                return LocList;
            }      

            public EmployeeData GetById(int EmployeeID)
            {
                EmployeeDetails Emp = new EmployeeDetails();
                EmployeeData Emps = new EmployeeData();
                List<EmployeeData> EmpList = new List<EmployeeData>();
                Emps = Emp.GetEmployeeByID(EmployeeID);
                return Emps;
            }

            public int Insert(EmployeeData employee)
            {
                EmployeeDetails Emp = new EmployeeDetails();
                List<EmployeeData> EmpList = new List<EmployeeData>();
               int result = Emp.InsertUpdateEmployeeDetails(employee);
               return result; 
            }
            public int Update(EmployeeData employee)
            {
                EmployeeDetails Emp = new EmployeeDetails();
                List<EmployeeData> EmpList = new List<EmployeeData>();
                int result = Emp.InsertUpdateEmployeeDetails(employee);
                return result;
            }
            public int Delete(int EmployeeID)
            {
                EmployeeDetails Emp = new EmployeeDetails();
                List<EmployeeData> EmpList = new List<EmployeeData>();
                int result = Emp.DeleteEmployeeDetails(EmployeeID);
                return result;
            }

           
            private bool disposed = false;

            protected virtual void Dispose(bool disposing)
            {
                if (!this.disposed)
                {
                    if (disposing)
                    {
                        Dispose();
                    }
                }
                this.disposed = true;
            }

            public void Dispose()
            {
                Dispose(true);

                GC.SuppressFinalize(this);
            }
        
    }
}
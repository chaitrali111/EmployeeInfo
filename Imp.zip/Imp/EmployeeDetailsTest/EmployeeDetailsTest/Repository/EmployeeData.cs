﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeDetailsTest.Repository
{
    public class EmployeeData
    {
        public int Srno { get; set; }
        public int ID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string MaritalStatus { get; set; }
        public int Salary { get; set; }
        public int LocationID{get;set;}
        public string LocationName{get;set;}
        public IEnumerable<SelectListItem> LocationList { get; set; }
    }

    public class Location
    {
        public int LocationId { get; set; }
        public string LocationName { get; set; }
    }
}
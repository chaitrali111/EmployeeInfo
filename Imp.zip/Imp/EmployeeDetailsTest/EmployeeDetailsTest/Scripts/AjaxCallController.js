﻿var AjaxCallController = function () { };
AjaxCallController.prototype = {
    MethodUrl: '',
    MethodObject: '',
    ActionType: 'Post',
    MethodSuccessFunction: 'OnSuccess',
    MethodErrorFunction: 'OnError',

    AjaxCall: function (obj) {
        $('#ModalBody').animate({ scrollTop: '0px' }, 300);
        var top = 0;
        var bottom = 0;
        var token = $('[name=__RequestVerificationToken]').val();
        if ($("#ModalBody").position() != null) {
            top = $("#ModalBody").position().top;
            bottom = top + $("#ModalBody").outerHeight();
        }

        var midPostion = ((bottom - top) / 2) + top - 20;
        midPostion = midPostion.toString() + "px";
        $("#divModalOperationLoader").css("top", midPostion);
        $("#divModalOperationLoader").html('<img src="../Images/ajax-loader-big.gif">');
        $("#ModalBody").addClass("OverLayGrid");


        if (obj.MethodUrl != '' && obj.MethodObject != '' && obj.MethodSuccessFunction != '' && obj.MethodErrorFunction != '') {
            $.ajax({
                url: obj.MethodUrl,
                contentType: 'application/json; charset=utf-8',
                cache: false,
                headers: { '__RequestVerificationToken': token },
                type: obj.ActionType,
                data: obj.MethodObject,
                dataType: "json",
                success: function (data) {
                    $("#divModalOperationLoader").empty();
                    $("#ModalBody").removeClass("OverLayGrid");
                    window[obj.MethodSuccessFunction](data);
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $("#divModalOperationLoader").empty();
                    $("#ModalBody").removeClass("OverLayGrid");
                    if (obj.MethodErrorFunction != '')
                        if (errorThrown != null) {
                            window[obj.MethodErrorFunction](errorThrown);
                        }
                }
            });
        }
        else {

            alert('Some of the required parmeters are missing.')
        }

    }
};